import java.util.*;

public class Simulator {
    // Constructor that takes in a List<Instruction>
    // corresponding to a program
    public Simulator(List<Instruction> prog) {}

    // simulate executes the program on the input tape,
    // and returns the resultant output tape
    public char[] simulate(char[] input) { return input; }
}