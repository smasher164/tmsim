import java.util.*;

public class Parser {
    // Constructor
    public Parser() {}

    // parse takes in a program written in the
    // turing machine's instruction set as a string,
    // and returns a List<Instruction>.
    public List<Instruction> parse(String prog) { return null; }
}